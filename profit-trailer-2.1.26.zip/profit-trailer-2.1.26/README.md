# ProfitTrailer
We trail the trends!

# Join the Discord group
If you have questions after reading the readme
### Main Channel
https://discord.gg/K9a37Vh

# Check out the wiki
https://wiki.profittrailer.com  

# How to run
https://wiki.profittrailer.com/doku.php/instructions  
